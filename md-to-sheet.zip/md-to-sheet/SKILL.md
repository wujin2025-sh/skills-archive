---
name: md-to-sheet
description: >-
  将Obsidian需求MD文件批量写入腾讯文档在线表格。读取指定目录下的需求MD文件，解析需求名称、描述、涉及系统等字段，
  去重后追加到腾讯文档表格中，自动处理超链接、多系统换行、背景色等格式。
  触发词：MD写入表格、需求导入表格、MD到腾讯文档、@tdoc配合MD文件、追加需求到表格。
  当用户同时提供腾讯文档表格引用（@tdoc）和本地MD文件路径，并要求将MD内容写入表格时触发。
agent_created: true
---

# MD需求文件写入腾讯文档表格

将本地Obsidian需求MD文件的结构化内容，批量解析并写入腾讯文档在线表格。

## 触发场景

- 用户提供 `@tdoc:"表格名"` 引用腾讯文档表格，同时有本地MD需求文件需要导入
- 用户说"把MD写入表格"、"把需求导入到腾讯文档"等
- 用户说"追加需求到表格"、"同步需求到表格"

## 表格列结构（0-indexed）

| 列号 | 列名 | 说明 | 写入方式 |
|------|------|------|---------|
| 0 | 提出日期 | 需求提出日期 | `set_range_value` STRING |
| 1 | 优先级 | 下拉选项 | `set_range_value` STRING，值"正常"（下拉需用户手动格式刷） |
| 2 | 需求链接 | Fintech平台链接 | `set_link` 设置超链接+显示文本 |
| 3 | 需求名称 | 完整需求标题 | `set_range_value` STRING |
| 4 | 需求描述 | 背景+内容 | `set_range_value` STRING，设置自动换行（背景色需JS脚本） |
| 5 | 涉及系统 | 🔴多系统换行（关键） | `set_range_value` STRING，设置自动换行，系统间**必须**用 `\n` 分隔 |
| 6 | 关联系统 | 关联系统 | `set_range_value` STRING，系统间用 `\n` 分隔 |
| 7 | 计划排期 | 上线计划 | `set_range_value` STRING |
| 8 | story拆分 | 是否拆分 | `set_range_value` STRING，默认"否" |
| 9 | 评审状态 | 评审结果 | `set_range_value` STRING，默认"待评审" |
| 10 | 备注 | 补充说明 | `set_range_value` STRING，默认留空 |
| 11 | 参会人员 | 参会人 | `set_range_value` STRING，留空 |

## 工作流程

### Step 1: 读取表格结构

1. 用 `get_sheet_info` 获取文件的所有子表信息（sheet_id、名称）
2. 用 `get_cell_data` 读取目标sheet的表头（row 0）和已有数据行，确定：
   - 列结构是否匹配上述标准
   - 最后一行数据的位置（新数据从 `lastRow + 1` 开始写入）
   - 已有需求名称列表（用于去重）

### Step 2: 读取MD文件

1. 从用户指定的目录读取MD文件，默认路径：`/Users/wujin/0000WorkFiles/myobsidian/Obsidian-Notes/需求分析/`
2. MD文件命名格式：`YYYYMMDD-需求-【系统名】需求标题.md`
3. 解析每个MD文件，提取以下字段：

**从文件名提取：**
- 提出日期：文件名前8位 `YYYYMMDD` → 转为 `YYYY/M/D` 格式
- 需求名称：文件名中 `需求-` 后的部分（去掉 `.md` 扩展名）

**从文件内容提取：**
- 需求描述：取"需求背景"和"需求内容"两个章节的正文，拼接为 `一、需求背景\n...\n\n二、需求内容\n...` 格式。省略"技术实现方案"和"评审纪要"章节
- 涉及系统：从MD内容中的系统标识提取（如"集中清算"、"低延时两融"、"参数中心"、"集中交易"等）。**关键：多个系统名必须用 `\n` 换行符连接，每个系统独占一行。严禁使用空格、顿号(、)、逗号(,) 或空格分隔符连接。**正确示例：`"低延时\n集中交易\n参数中心"`，错误示例：`"低延时 集中交易 参数中心"`
- 关联系统：如内容中提到"低延时已切换"等关联关系，提取为关联系统。多系统同样用 `\n` 换行符连接
- 计划排期：从"计划2026年XX月上线"提取为"X月份"
- 评审状态：从"评审结果：通过/不通过"提取，无则默认"待评审"
- 需求链接：从MD内容中的需求编号（如 `R2605250010`）拼接为 `https://fintech.gtht.com.cn/kjpt/DemandManage/details?demandId=RXXXXXXXXX&templateId=8888&flag=1`

### Step 3: 原地更新与追加 (Update & Append)

对比 MD 文件的需求名称与表格已有的需求名称（col 3）：
1. **有则更新**：若在线表格已存在同名需求，获取其所在行号。写入时仅覆盖更新提取到的动态属性（提出日期、描述、涉及系统、关联系统、排期、评审状态、参会人员、超链接），但**保留**已有的“优先级”、“story拆分”和“备注”字段，避免覆盖人工调整的数据。
2. **无则追加**：若不存在，则在表格第一个检测到的全空行位置追加写入新行。

### Step 4: 写入数据

按行写入，每行一个需求。关键格式处理：

**C列（需求链接）- 必须用 set_link：**
```
set_link(col=2, row=r, url=链接地址, display_text=链接地址)
```
注意：`set_link` 会覆盖原有文本，必须在 `set_range_value` 之后单独调用，且 `display_text` 必须传入链接地址本身作为显示文本。不可先 `set_range_value` 写C列再用 `set_link`——会导致内容丢失。

**F列（涉及系统）- 多系统换行（CRITICAL）：**

每个系统名之间必须用 `\n` 换行符分隔，确保在表格单元格中每个系统独占一行显示。

❌ **错误格式（会出现图1的问题 — 系统挤在一行）：**
```
set_range_value(sheet_id, "低延时 集中交易 参数中心", col=5, row=r)
set_range_value(sheet_id, "低延时、集中交易、参数中心", col=5, row=r)
```

✅ **正确格式（图2的目标效果 — 每个系统独占一行）：**
```
set_range_value(sheet_id, "低延时\n集中交易\n参数中心", col=5, row=r)
```

**写入前自检清单（MUST CHECK）：**
- [ ] 字符串中是否包含 `\n`？（必须包含，除非只有一个系统）
- [ ] 字符串中是否没有空格、顿号、逗号等连接符？（必须没有）
- [ ] 每个 `\n` 前后是否直接是系统名，无多余空格？

**E列背景色 - 用 operation_sheet JS脚本：**
```javascript
(function() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('sheetName');
  // 读取已有行的E列背景色作为参考
  var refBg = sheet.getRange(refRow, 5).getBackground();
  // 应用到新行
  for (var r = startRow; r <= endRow; r++) {
    var refRow = ((r % 2) === 0) ? 2 : 3; // 交替行颜色
    sheet.getRange(r, 5).setBackground(sheet.getRange(refRow, 5).getBackground());
    sheet.getRange(r, 5).setFontColor(sheet.getRange(refRow, 5).getFontColor());
    sheet.getRange(r, 5).setFontFamily(sheet.getRange(refRow, 5).getFontFamily());
    sheet.getRange(r, 5).setFontSize(sheet.getRange(refRow, 5).getFontSize());
  }
  return 'done';
})()
```

**所有列自动换行 - 用 set_cell_style：**
```json
{
  "file_id": file_id,
  "sheet_id": sheet_id,
  "start_col": 0,
  "end_col": 11,
  "start_row": r,
  "end_row": r,
  "wrap_text": true
}
```

**B列（优先级下拉）- API限制：**
腾讯文档API无法读写数据验证（下拉列表）。写入值"正常"即可，下拉指示器需用户手动从已有行格式刷复制 to 新行。

### Step 5: 验证

写入完成后，用 `get_cell_data` 读取新写入的行，确认数据正确性，向用户汇报写入结果。

## 运行同步脚本

已在 `scripts/md_to_sheet.py` 中封装了完整的解析与同步控制，可以通过以下命令行方式运行：

```bash
# 默认模式（等同于 rzrq）：仅读取及同步融资融券当日的需求 MD 文件
# 默认访问：https://docs.qq.com/sheet/DVGtPSXpzWU1zYXNi?tab=BB08J2 (融资融券需求跟踪)
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py
# 或显式传入 rzrq
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py rzrq

# 股票质押模式：仅读取及同步股票质押当日的需求 MD 文件
# 访问：https://docs.qq.com/sheet/DVEtyb05taEFDc0xL?tab=BB08J2 (股票质押需求跟踪)
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py gpzy

# 其他模式：仅读取及同步其他类型的当日需求 MD 文件
# 访问：https://docs.qq.com/sheet/DVE9Gb0daTmtzUE9H?tab=BB08J2 (其他需求跟踪)
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py qt

# 同步指定日期的股票质押需求
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py gpzy --date 20260602

# 同步所有历史日期的融资融券需求
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py rzrq --date all

# 预览模式（只解析预览，不实际修改表格）
python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py gpzy --dry-run
```

## 已知限制

1. **下拉选项**：腾讯文档API不支持数据验证（Data Validation）的读写，B列下拉需手动格式刷
2. **E列背景色**：`set_cell_style` 和 `clear_range_all` 对部分已设格式单元格无效，需用 `operation_sheet` JS脚本操作
3. **诊断数据清理**：`operation_sheet` JS脚本执行时如需写入诊断信息，务必在脚本最后用 `range.clear()` 清理，避免残留垃圾数据
4. **C列超链接**：`set_link` 会清除该单元格原有文本，必须设置 `display_text` 参数
5. **行号约定**：腾讯文档API和SpreadsheetApp的行列号均为1-based，`get_cell_data`/`set_range_value` 为0-based

## 使用样例与典型调用示例

### 场景 1：导入今日两融需求 (rzrq)
* **用户输入**：
  * `@tdoc:"融资融券需求跟踪" 把今天的两融需求写入表格`
  * `同步今天的两融需求MD到在线文档`
* **默认执行指令**：
  ```bash
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py rzrq
  ```
  *(注：如果不指定业务参数，脚本默认也是 `rzrq`)*

### 场景 2：导入今日股票质押需求 (gpzy)
* **用户输入**：
  * `@tdoc:"股票质押需求跟踪" 把今天的股票质押需求写入表格`
  * `同步今天的股质需求到在线表格`
* **默认执行指令**：
  ```bash
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py gpzy
  ```

### 场景 3：导入今日其他需求 (qt)
* **用户输入**：
  * `@tdoc:"其他需求跟踪" 把今天的其他非信用需求写入表格`
  * `同步今天的其他通用需求`
* **默认执行指令**：
  ```bash
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py qt
  ```

### 场景 4：同步特定日期的历史需求
* **用户输入**：
  * `@tdoc:"融资融券需求跟踪" 同步20260602的两融需求`
  * `把20260602的股质需求写入表格`
* **默认执行指令**（根据指定的日期和业务类型执行）：
  ```bash
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py rzrq --date 20260602
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py gpzy --date 20260602
  ```

### 场景 5：同步所有历史需求
* **用户输入**：
  * `@tdoc 同步所有历史两融需求`
  * `同步全部的历史其他需求`
* **默认执行指令**：
  ```bash
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py rzrq --date all
  python3 ~/.workbuddy/skills/md-to-sheet/scripts/md_to_sheet.py qt --date all
  ```

---

## 执行通用流程说明
1. 助手检测到触发词后，根据用户的意图（业务类型和日期参数），映射为对应的本地 Python 命令进行调用。
2. 脚本运行中会自动获取表格结构、读取本地对应日期的 MD 文件。
3. 对数据进行结构化解析后，智能判定“有则更新，无则追加”，批量执行单元格写入、链接设定，全列自动换行，并同步交替行背景色等格式。
4. 写入完成后，用 `get_cell_data` 校验正确性并向用户汇报写入结果。
