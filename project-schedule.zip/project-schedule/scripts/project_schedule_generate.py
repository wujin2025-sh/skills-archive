#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
project_schedule_generate.py — 项目进度表生成器
===================================================
并发运行 req_query.py 查询多个需求编号，解析生成的中间 Markdown 文件，
提取 Story 及排期数据，生成带合并单元格与风险标记的 HTML & Markdown 进度表。

当前系统时间固定为: 2026-06-10
"""

import sys
import os
import re
import asyncio
import argparse
from datetime import datetime

# 动态获取当前系统日期
CURRENT_DATE_TEMP = datetime.now()
CURRENT_DATE_STR = CURRENT_DATE_TEMP.strftime("%Y-%m-%d")
CURRENT_DATE_FILE_STR = CURRENT_DATE_TEMP.strftime("%Y%m%d")
CURRENT_DATE = datetime.strptime(CURRENT_DATE_STR, "%Y-%m-%d")

# 需求编号子标题硬编码映射
DEMAND_SUBTITLE_MAP = {
    "R2603130062": "富易网络投票切换清算",
    "R2603110056": "历史文件迁移到清算",
    "R2602120019": "银证转账历史文件迁移",
    "R2602120009": "交易历史文件迁移",
    "R2602120017": "担保费率等迁移参数后台",
}

# 已知 Story ID 到任务名称硬编码映射（优先匹配，保持历史一致性）
STORY_NAME_MAP = {
    "S2603160070": "富易网络投票切换清算配合",
    "S2603160083": "移动端网络投票切换封装配合",
    "S2603190133": "JY977-富易投票切换清算",
    "S2603190136": "富易投票接口切换测试配合",
    "S2603110132": "配合测试-历史文件迁移",
    "S2603110133": "委托和沪港通委托历史文件迁移",
    "S2603190060": "历史文件迁移非现场配合",
    "S2603190061": "历史文件迁移反洗钱配合",
    "S2603190062": "历史文件迁移信用业务配合",
    "S2605290172": "历史文件迁移大数据配合",
    "S2606080286": "配合历史数据迁移监控",
    "S2602120030": "银证转账迁移配合测试",
    "S2602120031": "银证转账迁移集中交易配合",
    "S2603110087": "银证转账迁移大数据模块",
    "S2603180160": "银证转账配合(BDNEW_3.1)",
    "S2603180162": "银证转账迁移反洗钱配合",
    "S2603180163": "银证转账迁移非现场配合",
    "S2602120011": "集中交易历史数据文件迁移",
    "S2602120012": "集中交易历史数据迁移配合",
    "S2603190066": "历史数据迁移非现场监控配合",
    "S2603190067": "历史文件迁移反洗钱监控配合",
    "S2603190068": "历史文件迁移信用业务配合",
    "S2602120027": "两融担保费率迁移至参数后台",
    "S2602120029": "两融历史文件迁移配合测试",
    "S2605290171": "两融历史文件迁移信用配合",
    "S2605290177": "两融历史文件迁移非现场配合"
}

def clean_story_name(story_id, original_name):
    if story_id in STORY_NAME_MAP:
        return STORY_NAME_MAP[story_id]
    
    # 通用清理规则
    name = re.sub(r'^【.*?】', '', original_name)
    name = re.sub(r'^JY\d+\-', '', name)
    name = name.strip()
    # 替换长词
    name = name.replace("等接口从集中交易切换至清算", "切换配合")
    name = name.replace("从集中交易迁移到集中清算", "迁移配合")
    name = name.replace("从集中交易迁移到三方存管", "迁移配合")
    name = name.replace("历史数据及文件从集中交易迁移到集中清算", "历史数据迁移")
    name = name.replace("历史文件从集中交易迁移到集中清算", "历史文件迁移")
    return name

def parse_owner(text):
    if not text or text.strip() == "/":
        return "/"
    # 提取 "姓名-工号" 中的 "姓名"
    return text.split('-')[0].strip()

def format_delivery_date(delivery_date, release_date, is_done):
    if delivery_date == "--" or not delivery_date:
        return "--"
    
    # 默认形式
    formatted = delivery_date
    
    if is_done:
        if release_date and release_date != "--":
            formatted += " (已发布)"
        else:
            formatted += " (已交付)"
    else:
        if release_date and release_date != "--":
            try:
                # 转换 2026-07-05 为 7-5发布
                dt = datetime.strptime(release_date, "%Y-%m-%d")
                formatted += f" ({dt.month}-{dt.day}发布)"
            except ValueError:
                pass
    return formatted

def compute_risk(delivery_date, is_done):
    if is_done:
        return "✅ 已完成"
    if delivery_date == "--" or not delivery_date:
        return "⚠️ 高 (需排期)"
    
    try:
        deliv_dt = datetime.strptime(delivery_date, "%Y-%m-%d")
        if deliv_dt < CURRENT_DATE:
            return "⚠️ 高 (已逾期)"
        elif (deliv_dt - CURRENT_DATE).days == 1:
            return "正常 (明日交付)"
        else:
            return "正常"
    except ValueError:
        return "正常"

def parse_result_file(file_path, demand_id):
    if not os.path.exists(file_path):
        return None
    
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # 提取需求标题
    title_match = re.search(r"^\s*　　\*\*标题\*\*：(.*)$", content, re.MULTILINE)
    title = title_match.group(1).strip() if title_match else ""
    
    # 提取期望上线时间
    expect_match = re.search(r"^\s*　　\*\*期望上线时间\*\*：(.*)$", content, re.MULTILINE)
    expect_date = expect_match.group(1).strip() if expect_match else ""
    
    # 获取子标题
    subtitle = DEMAND_SUBTITLE_MAP.get(demand_id, "")
    if not subtitle and title:
        subtitle = re.sub(r'^(JY\d+\-|【.*?】)', '', title).strip()
        if len(subtitle) > 15:
            subtitle = subtitle[:15] + "..."
            
    stories = []
    
    # 按 Story 拆分
    # 故事块特征: **数字. S编号** — 任务名称
    story_blocks = re.split(r"^\s*　　　　\*\*\d+\.\s*(S\d+)\*\*\s*—\s*(.*)$", content, flags=re.MULTILINE)
    
    # split 会返回: [前置内容, S编号1, 任务名称1, 故事1属性内容, S编号2, 任务名称2, 故事2属性内容, ...]
    if len(story_blocks) > 2:
        for idx in range(1, len(story_blocks), 3):
            story_id = story_blocks[idx].strip()
            raw_story_name = story_blocks[idx+1].strip()
            block_body = story_blocks[idx+2]
            
            # 解析属性
            # 状态：SIT生产测试待排期 | IT评估：已评估
            status_match = re.search(r"状态：([^\s|]*)\s*\|", block_body)
            status = status_match.group(1).strip() if status_match else ""
            
            # 系统：第三方存管系统  或  系统：大数据平台 | 工程排期：BDNEW_3.1
            system_match = re.search(r"系统：([^\n|]*)", block_body)
            system = system_match.group(1).strip() if system_match else ""
            
            # 开发负责人：李骎-109418 | SIT负责人：揭由翔-117919 | UAT负责人：何秉通-121798
            dev_match = re.search(r"开发负责人：([^\s|]*)", block_body)
            sit_match = re.search(r"SIT负责人：([^\s|]*)", block_body)
            uat_match = re.search(r"UAT负责人：([^\n|]*)", block_body)
            
            dev_owner = parse_owner(dev_match.group(1)) if dev_match else "/"
            sit_owner = parse_owner(sit_match.group(1)) if sit_match else "/"
            uat_owner = parse_owner(uat_match.group(1)) if uat_match else "/"
            
            # 计划交付：2026-05-21 | 发布日期：--
            deliv_match = re.search(r"计划交付：([^\s|]*)", block_body)
            rel_match = re.search(r"发布日期：([^\n|]*)", block_body)
            
            delivery_date = deliv_match.group(1).strip() if deliv_match else ""
            release_date = rel_match.group(1).strip() if rel_match else ""
            
            is_done = (status == "结束")
            
            # 清理故事名称
            story_name = clean_story_name(story_id, raw_story_name)
            
            # 计算风险与日期格式
            risk_status = compute_risk(delivery_date, is_done)
            plan_date_formatted = format_delivery_date(delivery_date, release_date, is_done)
            
            stories.append({
                "id": story_id,
                "name": story_name,
                "system": system,
                "dev_owner": dev_owner,
                "sit_owner": sit_owner,
                "uat_owner": uat_owner,
                "status": status,
                "delivery_date": plan_date_formatted,
                "risk_status": risk_status
            })
            
    return {
        "demand_id": demand_id,
        "title": title,
        "subtitle": subtitle,
        "expect_date": expect_date,
        "stories": stories
    }

async def run_single_query(req_id, script_dir):
    req_query_path = os.path.join(script_dir, "req_query.py")
    temp_md = os.path.join(script_dir, f"temp_{req_id}.md")
    
    print(f"[Orchestrator] 开始查询需求: {req_id}...")
    
    # 异步执行 req_query.py 子进程
    cmd = [sys.executable, req_query_path, req_id, "-o", temp_md]
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0 and os.path.exists(temp_md):
        print(f"[Orchestrator] 需求 {req_id} 查询成功。")
        return temp_md
    else:
        err_msg = stderr.decode('utf-8', errors='ignore')
        print(f"[Orchestrator] 需求 {req_id} 查询失败，返回值: {process.returncode}。错误信息: {err_msg}")
        return None

def generate_html(data_list, output_path, project_name):
    rows_html = []
    
    for idx, item in enumerate(data_list):
        demand_id = item["demand_id"]
        subtitle = item["subtitle"]
        stories = item["stories"]
        story_count = len(stories)
        
        # 需求分组顶边线样式
        row_style = ' style="border-top: 2px solid #94a3b8;"' if idx > 0 else ''
        
        if story_count == 0:
            # 没有故事的情况
            rows_html.append(f"""
      <tr{row_style}>
        <td class="req-col">
          {demand_id}
          <span class="req-sub">{subtitle}</span>
        </td>
        <td colspan="9" style="text-align: center; color: #64748b;">（无关联 Story）</td>
      </tr>""")
        else:
            for s_idx, story in enumerate(stories):
                # 状态列着色
                status_style = ""
                if story["status"] == "结束":
                    status_style = ' style="color: #047857; font-weight: 500;"'
                elif "自测" in story["status"] or "开发" in story["status"]:
                    status_style = ' class="badge-pending"'
                elif "待" in story["status"] or "待排期" in story["status"] or "待确认" in story["status"]:
                    status_style = ' style="color: #64748b;"'
                
                # 系统着色
                system_td = f'<td class="system-highlight">{story["system"]}</td>' if story["system"] == "集中清算系统" else f'<td>{story["system"]}</td>'
                
                # 风险状态样式
                risk_class = "badge-normal"
                if "已完成" in story["risk_status"]:
                    risk_class = "badge-done"
                elif "高" in story["risk_status"]:
                    risk_class = "badge-delay"
                elif "明日交付" in story["risk_status"]:
                    risk_class = "badge-normal"
                
                # 交付时间着色 (如果是明天交付加粗)
                date_style = ' style="font-weight: bold;"' if "明日交付" in story["risk_status"] else ""
                
                if s_idx == 0:
                    rows_html.append(f"""
      <tr{row_style}>
        <td rowspan="{story_count}" class="req-col">
          {demand_id}
          <span class="req-sub">{subtitle}</span>
        </td>
        <td>{story["id"]}</td>
        <td>{story["name"]}</td>
        {system_td}
        <td>{story["dev_owner"]}</td>
        <td>{story["sit_owner"]}</td>
        <td>{story["uat_owner"]}</td>
        <td{status_style}>{story["status"]}</td>
        <td{date_style}>{story["delivery_date"]}</td>
        <td class="{risk_class}">{story["risk_status"]}</td>
      </tr>""")
                else:
                    rows_html.append(f"""
      <tr>
        <td>{story["id"]}</td>
        <td>{story["name"]}</td>
        {system_td}
        <td>{story["dev_owner"]}</td>
        <td>{story["sit_owner"]}</td>
        <td>{story["uat_owner"]}</td>
        <td{status_style}>{story["status"]}</td>
        <td{date_style}>{story["delivery_date"]}</td>
        <td class="{risk_class}">{story["risk_status"]}</td>
      </tr>""")

    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{project_name}进度跟踪表</title>
<style>
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background-color: #F1EFE8;
    color: #2c2c2a;
    padding: 30px 20px;
    margin: 0;
  }}
  .container {{
    max-width: 1300px;
    margin: 0 auto;
    background-color: #ffffff;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(44, 44, 42, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.08);
  }}
  h2 {{
    font-size: 20px;
    font-weight: 700;
    color: #1e50a2;
    margin-bottom: 20px;
    border-bottom: 2px solid #1e50a2;
    padding-bottom: 10px;
  }}
  table {{
    border-collapse: collapse;
    width: 100%;
    font-size: 13px;
    text-align: left;
    margin-bottom: 20px;
  }}
  th {{
    background-color: #f1f5f9;
    color: #334155;
    font-weight: 700;
    padding: 12px 10px;
    border: 1px solid #cbd5e1;
  }}
  td {{
    padding: 12px 10px;
    border: 1px solid #cbd5e1;
    color: #334155;
  }}
  tr:hover {{
    background-color: #f8fafc;
  }}
  .req-col {{
    font-weight: bold;
    background-color: #f8fafc;
    color: #1e50a2;
    vertical-align: middle;
    text-align: center;
  }}
  .req-sub {{
    font-size: 11px;
    color: #64748b;
    font-weight: normal;
    display: block;
    margin-top: 4px;
  }}
  .badge-done {{
    color: #047857;
    font-weight: bold;
  }}
  .badge-pending {{
    color: #b45309;
  }}
  .badge-delay {{
    color: #b91c1c;
    font-weight: bold;
  }}
  .badge-normal {{
    color: #0284c7;
  }}
  .system-highlight {{
    font-weight: 500;
    color: #1e50a2;
  }}
</style>
</head>
<body>

<div class="container">
  <h2>{project_name}进度跟踪表 ({CURRENT_DATE_STR})</h2>
  <table>
    <thead>
      <tr>
        <th>需求编号</th>
        <th>Story 编号</th>
        <th>任务名称</th>
        <th>涉及系统</th>
        <th>开发负责人</th>
        <th>SIT 负责人</th>
        <th>UAT 负责人</th>
        <th>当前状态</th>
        <th>计划交付时间</th>
        <th>风险状态</th>
      </tr>
    </thead>
    <tbody>{"".join(rows_html)}
    </tbody>
  </table>
</div>

</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"[Orchestrator] 已成功生成 HTML 表格: {output_path}")

def generate_weekly_summary(data_list):
    total_demands = len(data_list)
    
    all_stories = []
    for item in data_list:
        demand_id = item["demand_id"]
        subtitle = item["subtitle"]
        for s in item["stories"]:
            s_copy = s.copy()
            s_copy["demand_id"] = demand_id
            s_copy["demand_subtitle"] = subtitle
            all_stories.append(s_copy)
            
    total_stories = len(all_stories)
    
    done_stories_list = [s for s in all_stories if s["status"] == "结束"]
    done_count = len(done_stories_list)
    
    pending_keywords = ["待", "确认", "排期"]
    pending_stories_list = []
    ongoing_stories_list = []
    
    for s in all_stories:
        if s["status"] == "结束":
            continue
        is_pending = any(kw in s["status"] for kw in pending_keywords)
        if is_pending or not s["delivery_date"] or s["delivery_date"] == "--":
            pending_stories_list.append(s)
        else:
            ongoing_stories_list.append(s)
            
    ongoing_count = len(ongoing_stories_list)
    pending_count = len(pending_stories_list)
    
    lines = []
    lines.append("")
    lines.append("## 周报汇报素材整理")
    lines.append("")
    lines.append("### 1. 整体进度概览")
    lines.append(f"- **涉及需求总数**: {total_demands} 个")
    lines.append(f"- **关联 Story 总数**: {total_stories} 个")
    lines.append(f"  - **已完成 (结束)**: {done_count} 个")
    lines.append(f"  - **进行中 (开发/SIT测试中)**: {ongoing_count} 个")
    lines.append(f"  - **待启动/待排期**: {pending_count} 个")
    lines.append("")
    
    lines.append("### 2. 重点逾期与风险预警")
    overdue_stories = [s for s in all_stories if "已逾期" in s["risk_status"]]
    no_schedule_stories = [s for s in all_stories if "需排期" in s["risk_status"]]
    
    if not overdue_stories and not no_schedule_stories:
        lines.append("- **正常**: 目前所有任务排期及进度正常，暂无明显逾期风险。")
    else:
        if overdue_stories:
            lines.append(f"- **⚠️ 逾期警告 (共计 {len(overdue_stories)} 个 Story 已逾期)**:")
            for s in overdue_stories:
                lines.append(f"  - **{s['id']}** ({s['name']}) — 系统: `{s['system']}` | 负责人: 开发-{s['dev_owner']} / SIT-{s['sit_owner']} | 计划交付时间: {s['delivery_date']}")
        if no_schedule_stories:
            lines.append(f"- **⚠️ 排期预警 (共计 {len(no_schedule_stories)} 个 Story 需排期)**:")
            for s in no_schedule_stories:
                lines.append(f"  - **{s['id']}** ({s['name']}) — 系统: `{s['system']}` | 负责人: 开发-{s['dev_owner']} / SIT-{s['sit_owner']} | 状态: {s['status']}")
    lines.append("")
    
    lines.append("### 3. 本周进展与下周计划素材")
    
    # Completed
    lines.append("- **本周已完成工作**:")
    if done_stories_list:
        sys_done = {}
        for s in done_stories_list:
            sys_done.setdefault(s["system"], []).append(s)
        for sys, s_list in sys_done.items():
            lines.append(f"  - **{sys}**:")
            for s in s_list:
                lines.append(f"    - 完成 {s['id']} ({s['name']}) 交付与发布。")
    else:
        lines.append("  - 本周无完成交付的 Story。")
        
    # Ongoing
    lines.append("- **下周计划与进行中工作**:")
    if ongoing_stories_list or pending_stories_list:
        sys_ongoing = {}
        for s in ongoing_stories_list + pending_stories_list:
            sys_ongoing.setdefault(s["system"], []).append(s)
        for sys, s_list in sys_ongoing.items():
            lines.append(f"  - **{sys}**:")
            for s in s_list:
                rel_info = f"，计划交付 {s['delivery_date']}" if s['delivery_date'] and s['delivery_date'] != "--" else ""
                lines.append(f"    - 推进 {s['id']} ({s['name']}) — 当前阶段: `{s['status']}`{rel_info}。")
    else:
        lines.append("  - 暂无进行中的 Story。")
        
    return "\n".join(lines)

def generate_markdown(data_list, output_path, project_name):
    lines = []
    lines.append(f"# {project_name}进度跟踪表 ({CURRENT_DATE_STR})")
    lines.append("")
    lines.append("| 需求编号 | Story 编号 | 任务名称 | 涉及系统 | 开发负责人 | SIT 负责人 | UAT 负责人 | 当前状态 | 计划交付时间 | 风险状态 |")
    lines.append("| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
    
    for item in data_list:
        demand_id = item["demand_id"]
        subtitle = item["subtitle"]
        stories = item["stories"]
        
        # 需求首列描述
        demand_col = f"**{demand_id}**<br>({subtitle})"
        
        if len(stories) == 0:
            lines.append(f"| {demand_col} | - | (无关联 Story) | - | - | - | - | - | - | - |")
        else:
            for s_idx, story in enumerate(stories):
                if s_idx == 0:
                    lines.append(f"| {demand_col} | {story['id']} | {story['name']} | {story['system']} | {story['dev_owner']} | {story['sit_owner']} | {story['uat_owner']} | {story['status']} | {story['delivery_date']} | {story['risk_status']} |")
                else:
                    lines.append(f"| | {story['id']} | {story['name']} | {story['system']} | {story['dev_owner']} | {story['sit_owner']} | {story['uat_owner']} | {story['status']} | {story['delivery_date']} | {story['risk_status']} |")
                    
    # 追加周报汇报素材概括内容
    summary_content = generate_weekly_summary(data_list)
    lines.append(summary_content)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
        f.write("\n")
    print(f"[Orchestrator] 已成功生成 Markdown 表格: {output_path}")

async def main_async():
    parser = argparse.ArgumentParser(description="批量生成项目进度跟踪表（HTML & Markdown）")
    parser.add_argument("demand_ids", nargs="+", help="需求编号列表（以空格分隔）")
    parser.add_argument("--output_html", default=None, help="生成的 HTML 表格路径")
    parser.add_argument("--output_md", default=None, help="生成的 Markdown 表格路径")
    parser.add_argument("--project", default="交易结算核心历史数据及接口迁移项目", help="项目名称")
    args = parser.parse_args()

    project_name = args.project.strip()
    html_path = args.output_html if args.output_html else f"{CURRENT_DATE_FILE_STR}-进度-{project_name}.html"
    md_path = args.output_md if args.output_md else f"{CURRENT_DATE_FILE_STR}-进度-{project_name}.md"

    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 并发查询所有需求
    tasks = [run_single_query(req_id.strip().upper(), script_dir) for req_id in args.demand_ids if req_id.strip()]
    temp_files = await asyncio.gather(*tasks)
    
    parsed_data = []
    for req_id, temp_file in zip(args.demand_ids, temp_files):
        req_id_upper = req_id.strip().upper()
        if temp_file and os.path.exists(temp_file):
            print(f"[Orchestrator] 解析中间结果: {temp_file}")
            data = parse_result_file(temp_file, req_id_upper)
            if data:
                parsed_data.append(data)
            # 清理中间文件
            try:
                os.remove(temp_file)
            except Exception as e:
                print(f"[Orchestrator] 无法删除临时文件 {temp_file}: {e}")
        else:
            print(f"[Orchestrator] 警告: 未能获取需求 {req_id_upper} 的数据，跳过该需求。")

    if not parsed_data:
        print("[Orchestrator] 错误: 没有成功获取到任何需求数据。")
        sys.exit(1)

    # 生成文件
    generate_html(parsed_data, html_path, project_name)
    generate_markdown(parsed_data, md_path, project_name)

    # 自动同步到 Obsidian 目录
    obsidian_dir = "/Users/wujin/0000WorkFiles/myobsidian/Obsidian-Notes/100_Projects/进度跟踪"
    try:
        os.makedirs(obsidian_dir, exist_ok=True)
        obsidian_md_path = os.path.join(obsidian_dir, f"{CURRENT_DATE_FILE_STR}-进度-{project_name}.md")
        generate_markdown(parsed_data, obsidian_md_path, project_name)
        print(f"[Orchestrator] 已成功同步写入 Obsidian 目录: {obsidian_md_path}")
    except Exception as e:
        print(f"[Orchestrator] 警告: 无法同步到 Obsidian 目录: {e}")

def main():
    asyncio.run(main_async())

if __name__ == "__main__":
    main()
