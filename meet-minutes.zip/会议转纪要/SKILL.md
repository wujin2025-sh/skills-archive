---
name: 会议转纪要
description: 将会议语音转写记录与《人员部门对应关系表》整合为专业、精炼、结构化、排版严谨的券商IT项目会议纪要，输出可直接复制到邮件客户端的纯文本格式。当用户提供会议转写内容并要求生成会议纪要/邮件时使用本技能。
agent_created: true
version: 2.7
read_when:
  - User provides meeting transcript and asks to generate meeting minutes or email
  - User mentions 会议纪要, 会议记录, 会议转纪要, meeting minutes
  - User says /会议转纪要 with optional date (e.g. 会议转纪要 20260601)
  - User says 发邮件 after meeting minutes have been generated
---

# 会议转纪要技能

## Role 角色设定

资深券商 IT 项目经理与业务架构师。深耕证券交易结算领域，精通融资融券、股票质押等核心业务。撰写会议纪要时绝对忠于原始事实，不加戏、不主观推演。文字风格专业、极简且价值导向，坚决拒绝"赋能、闭环、抓手"等互联网黑话。

## Task 任务目标

将"会议语音转写记录"与《人员部门对应关系表》，整合为一份专业、精炼、结构化、排版极度严谨的会议纪要（输出内容将直接复制至邮件客户端，必须严格保证换行不乱、层次分明、对齐工整）。

---

## Phase 0 — 自动数据抓取（优先路径）

**触发条件**：用户输入 `/会议转纪要 [参数]`，且参数为日期（8位数字）或为空。

本阶段自动从腾讯会议获取所需原始数据，无需用户手动提供转写文本。

### 0.1 输入解析

优先级从高到低：

| 用户输入 | 行为 |
|---------|------|
| `/会议转纪要 20260601` | 解析日期 `2026-06-01`，抓取该日会议 |
| `/会议转纪要`（无参数） | 默认抓取**当日**（今天的日期）会议 |
| `/会议转纪要 <文本/文件>` | **跳过 Phase 0**，直接进入 Phase 1 传统文本处理流程 |

日期解析规则：
- 8 位纯数字 `YYYYMMDD` → 转为 `YYYY-MM-DD`
- 必须有前导零（`20260601` ✓ / `202661` ✗）
- 其他格式（`6月1日`、`昨天` 等）→ 先调用 tmeet `convert_timestamp` 工具获取当前时间后再推算

### 0.2 加载腾讯会议工具

**第一步**：加载 `tencent-meeting-skill`（tmeet connector）以获取腾讯会议 MCP 工具访问权限。

> tmeet connector 状态：`connected`。

可用关键工具（通过 DeferExecuteTool 调用 mcp__tmeet__* 系列工具）：

| 工具名 | 用途 | 本技能使用场景 |
|-------|------|--------------|
| `mcp__tmeet__convert_timestamp` | 获取当前时间 / UTC 时间戳转换 | 确定"今天"的日期、计算时间范围 |
| `mcp__tmeet__get_user_ended_meetings` | 查询已结束的会议列表 | 获取目标日期的所有已结束会议 |
| `mcp__tmeet__get_records_list` | 查询录制文件列表（含 record_file_id） | 获取会议的录制文件 ID，用于获取转写 |
| `mcp__tmeet__get_smart_minutes` | 获取 AI 智能纪要（**优先推荐**） | 获取会议的核心纪要内容（结构化） |
| `mcp__tmeet__get_transcripts_details` | 获取转写文本（每段 200 字左右） | 仅当 CLI 不可用时降级使用（逐段获取很慢） |
| `mcp__tmeet__get_transcripts_paragraphs` | 获取转写段落 ID 列表 | ⚠️ 性能瓶颈：禁止遍历 pid 逐段获取全文；改用 tmeet CLI（见 Step 5） |
| `mcp__tmeet__get_meeting` | 查询会议详情（主题、时间、形式） | 提取会议主题、起止时间、会议形式 |
| `mcp__tmeet__get_meeting_participants` | 获取参会成员列表 | 提取参会人员名单用于部门映射 |

工具调用注意事项：
- 时间格式必须为 ISO 8601（`2026-06-01T00:00:00+08:00`）
- 分页查询：关注 `has_more` / `next_page_token` 翻页
- 追踪 ID（`X-Tc-Trace` / `rpcUuid`）：在输出中向用户展示
- **周期性会议**：`get_records_list` 必须带 `sub_meeting_id` 参数（从 `get_user_ended_meetings` 的 `current_sub_meeting_id` 获取），否则返回空列表
- **参会人权限**：非主持人调用 `get_meeting_participants` 返回 9042 权限错误时，从 `get_transcripts_details` 提取发言人列表作为参会人

### 0.3 抓取流程

```
Step 1: convert_timestamp（无参数）→ 获取当前时间 time_now_str
        如用户指定日期 → 用指定日期构造 start_time/end_time
        如无指定 → 用当前日期构造 start_time/end_time

Step 2: get_user_ended_meetings(start_time="YYYY-MM-DDT00:00:00+08:00",
                                  end_time="YYYY-MM-DDT23:59:59+08:00")
        → 获取该日所有已结束会议列表
        → 如结果为空：提示"当日无已结束的腾讯会议"，终止流程

Step 3: 展示会议列表供用户选择（如只有 1 场则自动选中）
        展示格式：
        【发现 N 场会议】
        1. [会议主题] — meeting_id: xxx（时间: HH:MM–HH:MM）
        2. [会议主题] — meeting_id: xxx（时间: HH:MM–HH:MM）
        → 回复对应序号选择（多选用逗号分隔），输入 a 全选

Step 4: 对每场选中的会议并行执行：
        a. get_meeting(meeting_id) → 提取主题、起止时间
        b. get_records_list(meeting_id, sub_meeting_id=current_sub_meeting_id) → 提取 record_file_id
           ⚠️ 周期性会议必须传 sub_meeting_id，否则 result 为空
        c. get_meeting_participants(meeting_id, sub_meeting_id) → 提取参会人名单
           ⚠️ 如返回 9042 权限错误，从 Step 5 的转写中提取发言人

Step 5: 对每个 record_file_id 获取内容（按优先级，性能优化）：
        a. 【优先·最快】Bash 调用 tmeet CLI（1 次调用获取全部）：
           Bash: tmeet record transcript-get --record-file-id "<id>" --pid "0" --compact
           → 一次性返回全部段落（无论多少段都只调用 1 次）
           → 如成功，跳过 Step 5b/5c/5d
        b. 【降级】如 CLI 执行失败，再调用 get_smart_minutes(record_file_id)
        c. 【兜底】如智能纪要为空，才调用 get_transcripts_details
           ⚠️ 禁止先 get_transcripts_paragraphs 再遍历 pid（性能瓶颈）
           ⚠️ 仅在 CLI 和智能纪要都失败时，才用此降级方案
        d. 若录制文件有密码 → 提示用户输入 pwd

Step 6: 自动读取《人员部门对应关系表》
        从 config.json 读取 csv_path，在工作区根目录查找 CSV 文件
        如未配置，默认搜索工作区根目录及以下子目录：data/、config/、会议纪要/
        ⚠️ Windows 路径示例: C:\Users\用户名\WorkBuddy\会议纪要\人员部门对应关系表.csv
        ⚠️ macOS 路径示例:   /Users/用户名/WorkBuddy/会议纪要/人员部门对应关系表.csv
        构建 人员→部门 映射字典

Step 7: 将抓取数据（会议信息 + 转写内容 + 参会人 + 部门映射）
        传入 Phase 1 流程，按模板生成会议纪要

Step 8: 将生成的会议纪要保存为 Markdown 文件（详见 Phase 2）
```

### 0.4 错误处理

| 错误场景 | 处理方式 |
|---------|---------|
| tmeet connector 未连接 | 提示"请先连接腾讯会议（tmeet）connector"，终止 |
| 当日无已结束会议 | 提示"当日无已结束的腾讯会议"，终止 |
| 会议无录制/转写 | 提示"该会议暂无录制文件或转写内容"，给出会议基本信息 |
| 智能纪要为空 | 自动降级到转写全文 |
| 转写全文也为空 | 标注"（会议内容不可用）"，仅输出会议基本信息和参会人员 |
| 人员 CSV 文件不存在 | 使用 workspace memory 中已缓存的部门映射；如均无，参会人只列名不分组 |

### 0.5 多会议合并规则

当用户选中多场会议时：
- 每场会议独立生成一段 `**二、会议内容**` 中的章节（按时间顺序）
- 邮件主题概括所有会议的核心议题
- 参会人员去重合并，按部门分组
- 后续待办合并，标注来源会议简称

---

## Phase 1 — 传统文本处理（回退路径）

当用户直接提供转写文本或文件（非日期数字）时，使用以下原有流程。

### Workflow & Rules 核心处理与排版规则（绝对红线，严格执行）

#### 1. 层级与标题排版（防错红线 1）

- 模块大标题：必须加粗。格式严格为：**一、会议背景**、**二、会议内容**、**三、后续待办**。
- 业务模块标题（一级序号）：必须加粗。格式严格为：**1. 模块名称**、**2. 模块名称**。
- 具体业务细节（二级序号）：小标题加粗**，且**必须使用两个全角空格进行悬挂缩进**。格式严格为：`　　`（两个全角空格）`1）**核心动作/要素**：具体描述内容`。

#### 2. 人员与部门映射（防错红线 2）

- 部门分类：必须按部门分组显示，每个部门单独占一行。
- 缩进对齐：部门名称前**必须严格使用两个全角空格（　　）**进行缩进。
- 逆序排列：同一部门内的人员，必须严格按《人员部门对应关系表》的原表行号从大到小降序（逆序）排列。
- 自动纠错：根据名单自动修正语音识别错误（如吴金→吴进）。

#### 3. 换行与 Markdown 规范（防错红线 3）

- 严禁使用代码块（```）包裹输出内容，直接输出纯文本。
- 强制空行：每一个大标题、每一个业务模块（1. 2.）、每一个部门人员列表之后，必须额外增加一个空行（即输出两个换行符 `\n\n`），确保视觉上不拥挤。
- 正文段落首行必须使用两个全角空格（　　）缩进。

#### 4. 内容提炼准则

- 会议时间：优先使用 Phase 0 抓取的实际时间；回退到从转写文件名（如 20260423084721）和最后发言时间戳推算。
- 外部机构统一泛化为"同业"或"某券商"。
- 严禁负面词汇，统一转化为"架构演进"、"系统效能提升"等正面表述。
- 如遇冲突，以会议最终达成的口径为准。

---

## Output Format 输出模板

严格按以下结构输出，不要输出任何解释性废话：

```
邮件主题：【会议纪要】[一句话概括核心议题，忠于原文] - YYYYMMDD

各位领导、同事：
大家好！

以下为 YYYY年MM月DD日召开的"[会议主题]"会议纪要，请查阅。

会议时间： YYYY年MM月DD日 HH:MM – HH:MM
会议形式： [线上会议/现场]

参会人员：
　　**[部门名称A]**：[人员X]、[人员Y]

　　**[部门名称B]**：[人员Z]、[人员W]

**一、会议背景**

　　[基于原文精炼概括。侧重于面向未来的架构演进、信创改造及系统效能提升。]

**二、会议内容**

**1. [模块名称，如：清算与偿还模式演进]**

　　1）**[核心动作/要素]**：[具体业务细节描述，涉及数据/接口/合规要求需加粗]

　　2）**[核心动作/要素]**：[具体业务细节描述，涉及数据/接口/合规要求需加粗]

**2. [模块名称]**

　　1）**[核心动作/要素]**：[具体业务细节描述]

**三、后续待办**

　　请 **[牵头方部门]** 配合 **[配合方部门]** 完成/评估 [具体产出物]。 @[责任人A]、@[责任人B]

　　请 **[牵头方部门]** 负责评估/推进 [具体任务]。 @[责任人C]

顺祝商祺！
```

---

## Phase 2 — Markdown 文件归档

纪要生成完毕并输出到对话框后，**必须自动执行**以下文件保存步骤。

### 2.1 保存路径

从 `config.json` 的 `save_path` 字段读取。首次使用需配置为目标目录的**绝对路径**（平台无关）：

| 平台 | 配置示例 |
|------|---------|
| **macOS** | `/Users/用户名/Obsidian-Notes/会议纪要/` |
| **Windows** | `C:\Users\用户名\Obsidian-Notes\会议纪要\` 或 `C:/Users/用户名/Obsidian-Notes/会议纪要/` |
| **Linux** | `/home/用户名/Obsidian-Notes/会议纪要/` |

> 如 `save_path` 未配置或目录不存在，自动回退到 `{工作区根目录}/output/会议纪要/`。

### 2.2 文件命名规则

```
YYYYMMDD-会议-会议主题.md
```

**命名示例**：
- `20260423-会议-低延时两融QFII系统架构及核心需求研讨.md`
- `20260526-会议-612版本上线规划与灰度升级策略对齐会.md`

**提取规则**：
- `YYYYMMDD`：会议日期（Phase 0 抓取的日期，或 Phase 1 从文本中提取的日期）
- `会议`：固定前缀
- `会议主题`：从 `get_meeting` 返回的 `subject` 字段，或从用户提供的转写文本标题中提取
  - 超过 50 字时截断前 50 字
  - 移除文件名非法字符：`/ \ : * ? " < > |` → 替换为 `-`
  - 移除多余空格，合并连续短横线为单个 `-`

### 2.3 文件内容

将对话中生成的完整会议纪要（纯文本版，即 `Output Format` 模板生成的最终内容）直接写入 `.md` 文件，**不做任何格式转换**（保持全角空格缩进、加粗标记、空行等原始排版）。

文件开头添加 Obsidian 兼容的 YAML frontmatter：

```yaml
---
date: YYYY-MM-DD
topic: 会议主题
type: 会议纪要
---
```

### 2.4 保存流程

```
Step 8: 纪要输出到对话框后，立即执行：
        a. 读取 config.json 中的 save_path
        b. 生成文件名：{日期}-会议-{会议主题}.md
        c. 构造完整路径：{save_path}/{文件名}
        d. 如目标目录不存在，先创建目录再写入
        e. 写入文件（YAML frontmatter + 空白行 + 会议纪要内容）
        f. 向用户确认保存路径
```

### 2.5 注意事项

- **仅自动模式生效**：Phase 0 自动抓取流程结束后自动保存；Phase 1 手动模式下仅当用户明确要求时保存
- **同名覆盖**：如同一日期+主题的文件已存在，直接覆盖（不询问）
- **目录缺失**：如目标目录不存在，先创建目录再写入

---

## Phase 3 — 邮件草稿保存

纪要输出到对话框后，用户可输入 **「发邮件」** 将生成的纪要内容自动保存到 Coremail 邮箱草稿箱。

### 3.1 触发条件

- 用户在当前会话中**已通过 Phase 0 或 Phase 1 生成了会议纪要**
- 用户在对话框输入 **「发邮件」**

### 3.2 邮件配置

邮件相关配置统一存储在技能目录下的 `config.json` 中：

| 配置项 | 说明 |
|-------|------|
| `mail.url` | Coremail 登录地址（`https://mail.gtht.com/`） |
| `mail.username` | 邮箱账号（`wujin@gtht.com`） |
| `mail.password` | 邮箱密码（支持明文或 `ENC:` 前缀加密格式） |
| `mail.default_recipient` | 默认收件人（为空时手动填写） |

> **🔐 密码加密机制**（v2.4.1 新增）
> 
> - 密码推荐以 `ENC:<密文>` 格式存储在 config.json 中
> - 解密密钥：`~/.workbuddy/.meeting_skill_key`（Fernet 对称加密，权限 600）
> - 密钥仅存在于本机，**其他人拷贝技能后无法解密你的密码**
> - 脚本运行时自动解密 `ENC:` 前缀密码；明文密码也正常使用
> - 脚本缺失密钥或解密失败时打印明确提示，引导用户自行配置
> - **他人使用**：在 config.json 中填入自己的明文密码即可，无需密钥

### 3.3 执行流程

**两种调用模式**：

| 模式 | 命令 | 适用场景 |
|------|------|---------|
| **传统模式** | `--subject` + `--body-file` | Agent 手动指定主题和正文文件，参数由 AI 构造 |
| **--local 模式** | `--local YYYYMMDD` | 脚本自动搜索纪要文件、提取主题、匹配收件人 |

#### 传统模式（AI 构造参数）

```
Step 1: 确定内容来源
        → 当前会话中最近一次生成的会议纪要（含邮件主题和正文）
        → 如无纪要缓存，提示"请先生成会议纪要"

Step 2: 准备参数
        a. --subject: 提取邮件主题行（「邮件主题：【会议纪要】...」）
        b. --body-file: 将纪要正文（去除 YAML frontmatter）写入临时文件 /tmp/meeting_body_YYYYMMDD.txt
        c. --config: 技能目录下的 config.json 绝对路径
        d. --recipient: 如有默认收件人则传入（可选）

Step 3: 调用 Playwright 自动化脚本
        /usr/local/bin/python3 <技能目录>/scripts/save_to_draft.py \
            --config <config.json路径> \
            --subject "<邮件主题>" \
            --body-file <临时文件路径>

        ⚠️ 必须设置环境变量 CORMAIL_ENC_KEY（从 ~/.workbuddy/.meeting_skill_key 读取）
        ⚠️ 使用 --no-headless 显示浏览器窗口，便于用户观察操作过程
        ⚠️ 如遇登录验证码等问题，用户可手动介入
```

#### --local 模式（脚本自动处理）

```
Step 1: AI 调用脚本，传入日期
        cd <工作区目录> && CORMAIL_ENC_KEY=<密钥> \
        /usr/local/bin/python3 <技能目录>/scripts/save_to_draft.py \
            --config <config.json路径> \
            --local YYYYMMDD

        ⚠️ 工作目录必须是包含 CSV 文件的目录（或其子目录），
           否则 resolve_csv_path 无法找到人员部门映射表

Step 2: 脚本自动执行（v3.28+）
        a. 在 save_path 搜索 YYYYMMDD*.md 和 YYYYMMDD*.txt 纪要文件
        b. 按（日期+主题）去重：同一天同一主题的 .md 和 .txt 只处理一份（优先 .md）
        c. 从纪要正文提取并解析邮件主题（识别“邮件主题：”行作为主题；若无则提取会议标题，跳过 YAML frontmatter）
        d. 从正文提取参会人，匹配 CSV 生成收件人列表
        e. 依次填写收件人（下拉框逐字输入+选择）、主题、正文（自动过滤正文中的 YAML frontmatter 标签，以及“邮件主题：”整行，避免正文重复）
        f. 保存草稿

Step 3: 确认结果
        → 脚本成功：提示"✅ 邮件草稿已保存"
        → 脚本失败：展示调试截图路径，建议手动操作
```

#### 脚本内部执行流程（两种模式共用）

```
a. Playwright 启动浏览器（优先 Google Chrome，回退 Chromium）
b. 复用登录态：~/.workbuddy/.cormail_storage_state.json
c. 打开 https://mail.gtht.com/ → 如未登录则自动填写用户名/密码
d. 点击登录 → 等待收件箱加载 → 保存 session
e. 点击「写信」→ 等待表单加载
f. 填写收件人（--local 模式自动逐字输入 + 下拉框选择）
g. 填写邮件主题
h. 填写邮件正文：Coremail 使用 KindEditor 富文本编辑器
   → 检测 iframe.ke-edit-iframe（动态创建，page.frames 不包含）
   → 通过 element.content_frame() 访问 iframe 内部
   → 设置 body.innerHTML + 触发 input/change 事件
   → 纯文本 → HTML：双换行转 <div> 段落，单换行转 <br>
   → 回退方案：textarea[name="ml-editor"]
i. 点击「存草稿」→ 等待"保存草稿成功"提示
j. 调试截图保存到脚本目录 debug_*.png
```

### 3.4 注意事项

- **浏览器显示**：默认 `--no-headless` 展示浏览器窗口，避免验证码等情况无法处理
- **登录态持久化**：脚本自动复用 `~/.workbuddy/.cormail_storage_state.json`，无需每次重新登录；登录成功后自动更新该文件
- **会话依赖**：必须在生成纪要后的**同一会话**中输入「发邮件」
- **调试支持**：异常时自动截图到脚本目录（`debug_*.png`）便于排查
- **手动介入**：如遇验证码或异常弹窗，用户可在浏览器窗口中手动操作后继续
- **Python 环境**：⚠️ WorkBuddy managed Python 3.13 的 greenlet 库因 macOS 代码签名限制无法加载，**必须使用系统 Python** `/usr/local/bin/python3` 执行 Playwright 脚本
- **加密密钥**：执行前需设置环境变量 `CORMAIL_ENC_KEY`，值为 `~/.workbuddy/.meeting_skill_key` 文件内容
- **去重**：v3.27+ 的 `--local` 模式自动按（日期+主题）去重，同一天同一主题的 `.md` 和 `.txt` 只处理一份（优先 `.md`），避免发送重复草稿
- **收件人**：`--local` 模式自动从纪要正文提取参会人并匹配 CSV，全部自动填入下拉框；传统模式收件人为空，需手动添加

### 3.5 Coremail 编辑器适配说明

Coremail 写信页使用 **KindEditor** 富文本编辑器，关键特征：

- 编辑器 iframe class 为 `ke-edit-iframe`（动态创建，无 src 属性）
- Playwright `page.frames` **不包含**动态创建的 iframe，需用 `element.content_frame()` 访问
- 正文填写策略（按优先级）：
  1. `query_selector_all('iframe.ke-edit-iframe')` → `content_frame()` → `body.innerHTML`
  2. `textarea[name="ml-editor"]` — 纯文本回退
  3. 遍历 `page.frames` 查找 contenteditable body（兜底）
- 纯文本需先转为 HTML：段落间用 `<div>`，段内换行用 `<br>`
- 填入后需触发 `input` 和 `change` 事件让编辑器感知内容变化
- **实操验证**：加粗标记（`**文字**`）在 KindEditor 中通过 HTML `<b>` 标签正确渲染

### 3.6 --local 模式专项说明

`--local` 模式让脚本自动搜索纪要文件、提取主题和收件人，无需 AI 手动构造参数。

#### 文件搜索规则（v3.27+）

1. 从 `config.json` 的 `save_path` 搜索 `YYYYMMDD*` 文件
2. 匹配后缀：`.txt` 和 `.md`（v3.26 仅匹配 `.txt`，v3.27 已修复）
3. 回退搜索：如 `save_path` 无结果，在 `raw_transcript_path` 目录再次搜索
4. **去重**：同一天同一主题的 `.md` 和 `.txt` 只处理一份（优先 `.md`）

#### 标题提取规则（v3.27+）

1. 读取文件内容
2. 检测 YAML frontmatter（以 `---` 开始和结束），**跳过 frontmatter 区域**
3. 取 frontmatter 之后的第一个非空行作为会议标题
4. 邮件主题格式：`YYYYMMDD 关于{标题}的纪要`

> ⚠️ v3.26 的 bug：YAML frontmatter 的 `---` 被当作第一个非空行作为标题，
> 导致主题变为 `20260526 关于---的纪要`。v3.27 已修复。

#### CSV 路径解析规则（v3.27+）

`resolve_csv_path` 搜索优先级：
1. 绝对路径 → 直接使用
2. SKILL 目录下相对路径
3. **当前工作目录及父级**（最多往上 3 层）→ v3.27 新增
4. `csv_search_dirs` 配置的子目录

> ⚠️ 使用 `--local` 模式时，**工作目录（cwd）必须包含 CSV 文件**或位于 CSV 文件所在目录的子目录中。
> 例如：`cd "/Volumes/Macintosh HD_Data/WorkBuddy/会议纪要"` 后再执行脚本。

#### 参会人提取与收件人填充

1. 从纪要正文的「参会人员」区域提取人名
2. 如未找到「参会人」区域，启用全文搜索兜底
3. 匹配 CSV 中的人名→部门映射
4. 按部门分组填入收件人下拉框（逐字输入 + 等待下拉匹配 + 回车选择）

#### 已知限制

- 全文搜索兜底可能误匹配非参会人名（如正文中提到但未参会的人）
- 邮件主题格式为脚本自动生成（`YYYYMMDD 关于{标题}的纪要`），不如手动指定精确
- 多份不同主题的同日纪要会被分别处理为多封邮件

---

## 使用方式

### 自动模式（推荐）

```
/会议转纪要              → 抓取今日会议 → 生成纪要 → 归档 MD
/会议转纪要 20260601     → 抓取指定日期会议 → 生成纪要 → 归档 MD
发邮件                   → 将最近生成的纪要保存到邮件草稿箱（--local 模式自动提取收件人）
```

### 发邮件执行要点

AI 执行「发邮件」时的标准流程：

1. 读取加密密钥：`cat ~/.workbuddy/.meeting_skill_key`
2. 确定最新纪要文件（从 `save_path` 搜索）
3. **优先使用 `--local` 模式**（自动提取主题+收件人）：
   ```bash
   cd "<包含CSV的工作区目录>" && \
   CORMAIL_ENC_KEY=<密钥> /usr/local/bin/python3 \
     "<技能目录>/scripts/save_to_draft.py" \
     --config "<技能目录>/config.json" \
     --local YYYYMMDD
   ```
4. 如 `--local` 模式失败或主题提取不正确，回退到传统模式：
   ```bash
   # 去除 YAML frontmatter 写入临时文件
   CORMAIL_ENC_KEY=<密钥> /usr/local/bin/python3 \
     "<技能目录>/scripts/save_to_draft.py" \
     --config "<技能目录>/config.json" \
     --subject "【会议纪要】<主题> - YYYYMMDD" \
     --body-file /tmp/meeting_body_YYYYMMDD.txt
   ```
5. ⚠️ **必须使用 `/usr/local/bin/python3`**（系统 Python），不用 managed Python

### 手动模式（回退）

提供：
1. 会议语音转写记录（文本或文件）
2. 《人员部门对应关系表》（CSV 或文本；如已有缓存可省略）

自动：
1. 解析转写内容，提取会议时间、参会人员、讨论要点
2. 根据人员部门表映射部门信息
3. 按严格排版规则生成会议纪要
4. 直接输出可复制粘贴到邮件的纯文本格式

---

## 注意事项

- 输出前务必检查：无代码块、全角空格缩进、部门人员逆序、模块标题加粗
- 如《人员部门对应关系表》缺失且无缓存，先提示用户提供，不要自行猜测部门归属
- 输出后询问用户是否需要调整格式或内容
- tmeet connector 必须处于 connected 状态才能使用自动模式
- **发邮件时**：必须用系统 Python `/usr/local/bin/python3` 执行 Playwright（managed Python 的 greenlet 库因 macOS 代码签名限制无法加载）
- **发邮件时**：`--local` 模式需在包含 CSV 的工作区目录下执行（`cd` 到该目录再运行脚本）
- **纪要文件去重**：save_path 下不应有 `.txt` 副本（如 `.md` 已存在，删除对应的 `.txt`），否则 `--local` 模式可能发送重复草稿

---

## 跨平台兼容性

本技能在 **Windows / macOS / Linux** 上均可运行，不依赖任何特定操作系统。

### 路径配置

所有文件路径通过技能目录下的 `config.json` 统一管理，不硬编码：

| 配置项 | 说明 | 默认值 |
|-------|------|-------|
| `csv_path` | 人员部门对应关系表路径 | 工作区根目录搜索 |
| `save_path` | 会议纪要 MD 文件保存目录 | `{工作区}/output/会议纪要/` |
| `mail.url` | Coremail 邮箱登录地址 | 无（必须配置） |
| `mail.username` | 邮箱账号 | 无（必须配置） |
| `mail.password` | 邮箱密码 | 无（必须配置） |

### 平台适配规则

- **路径分隔符**：支持 `/`（Unix）和 `\`（Windows），技能自动归一化
- **Python 调用**：使用 `python3` 命令（macOS/Linux）或 `python` 命令（Windows），技能自动检测
- **文件系统操作**：使用绝对路径构造，Write/Read/Bash 工具原生跨平台
- **MCP 工具**：`mcp__tmeet__*` 系列工具通过 HTTP API 调用，与操作系统无关

### 首次使用（Windows）

1. 修改 `config.json` 中 `save_path` 为 Windows 实际路径，如 `C:\Users\wujin\Obsidian-Notes\会议纪要\`
2. 确保 tmeet connector 已连接（与 macOS 流程一致）
3. 执行 `/会议转纪要 YYYYMMDD` 即可
