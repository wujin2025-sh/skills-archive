#!/usr/bin/env python3
"""极速雷达索引构建器 — 一次构建，永久享受毫秒级搜索"""
import os, sys, json, time, zipfile, xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed

WORKSPACE = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INDEX     = os.path.join(WORKSPACE, ".workbuddy", "_radar_index.txt")
MANIFEST  = os.path.join(WORKSPACE, ".workbuddy", "_radar_manifest.json")
BIN_EXTS  = {'.pdf', '.docx', '.xlsx', '.xls'}
WORKERS   = 8
_W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
_S_NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def scan_pdf(fp):
    lines = []
    try:
        from PyPDF2 import PdfReader
        for i, p in enumerate(PdfReader(fp, strict=False).pages, 1):
            t = p.extract_text()
            if not t: continue
            for j, ln in enumerate(t.split('\n')):
                ln = ln.strip()
                if ln:
                    lines.append(f"{fp}\tP{i}L{j+1}\t{ln}")
    except:
        pass
    return lines

def scan_docx(fp):
    lines = []
    try:
        with zipfile.ZipFile(fp) as z:
            if 'word/document.xml' not in z.namelist(): return lines
            xml = z.read('word/document.xml')
        texts = []
        for t in ET.fromstring(xml).iter(f'{{{_W_NS}}}t'):
            if t.text: texts.append(t.text)
        if texts:
            full = ' '.join(texts)
            for j, ln in enumerate(full.split('\n')):
                ln = ln.strip()
                if ln:
                    lines.append(f"{fp}\tL{j+1}\t{ln}")
    except:
        pass
    return lines

def scan_xlsx(fp):
    lines = []
    try:
        with zipfile.ZipFile(fp) as z:
            if 'xl/sharedStrings.xml' not in z.namelist(): return lines
            xml = z.read('xl/sharedStrings.xml')
        for i, si in enumerate(ET.fromstring(xml).findall(f'{{{_S_NS}}}si')):
            t = ''.join(t.text or '' for t in si.iter(f'{{{_S_NS}}}t')).strip()
            if t:
                lines.append(f"{fp}\tR{i+1}\t{t}")
    except:
        pass
    return lines

def scan_xls(fp):
    lines = []
    try:
        import xlrd
        wb = xlrd.open_workbook(fp, on_demand=True)
        for sn in wb.sheet_names():
            ws = wb.sheet_by_name(sn)
            for ri in range(ws.nrows):
                for ci in range(ws.ncols):
                    v = ws.cell_value(ri, ci)
                    if isinstance(v, str) and v.strip():
                        lines.append(f"{fp}\t{sn}:R{ri+1}C{ci+1}\t{v.strip()}")
    except:
        pass
    return lines

def scan_file(fp):
    ext = os.path.splitext(fp)[1].lower()
    if ext == '.pdf':   return scan_pdf(fp)
    elif ext == '.docx': return scan_docx(fp)
    elif ext == '.xlsx': return scan_xlsx(fp)
    elif ext == '.xls':  return scan_xls(fp)
    return []

# ---- 收集文件 + 记录 mtime ----
files = []
manifest = {}
for root, dirs, fns in os.walk(WORKSPACE):
    dirs[:] = [d for d in dirs if not d.startswith('.')]
    for fn in fns:
        if fn.startswith('~$'): continue
        fp = os.path.join(root, fn)
        ext = os.path.splitext(fn)[1].lower()
        if ext in BIN_EXTS:
            st = os.stat(fp)
            files.append(fp)
            manifest[fp] = [st.st_mtime, st.st_size]

print(f"索引构建中: {len(files)} 个二进制文件...")
t0 = time.time()
all_lines = []

with ThreadPoolExecutor(max_workers=WORKERS) as ex:
    futures = {ex.submit(scan_file, fp): fp for fp in files}
    for fut in as_completed(futures):
        all_lines.extend(fut.result())

# 排序便于二分搜索
all_lines.sort()

# 写入索引
os.makedirs(os.path.dirname(INDEX), exist_ok=True)
with open(INDEX, 'w', encoding='utf-8') as f:
    f.write(f"# 极速雷达索引 | {len(all_lines)} 行 | {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write('\n'.join(all_lines))

# 写入 manifest
with open(MANIFEST, 'w') as f:
    json.dump(manifest, f)

print(f"索引完成: {len(all_lines)} 行, 耗时 {time.time()-t0:.1f}s")
