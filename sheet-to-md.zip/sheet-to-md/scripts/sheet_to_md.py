#!/usr/bin/env python3
"""
腾讯文档 Sheet → Obsidian MD 反写工具 v6

从腾讯文档在线表格 CSV 数据中提取需求记录，按需求名称匹配本地 MD 文件：
- J列=「通过」才处理，否则跳过
- 将 关联系统(G) 自然融入「技术实现」章节
- 将 涉及系统(F)、计划排期(H)、备注(K)、参会人员(L) 融入「评审纪要」章节
- K列(备注) → 优先合并到现有编号条目，否则新增编号条目（如 4. **标题**：内容）
- 涉及系统(F) 放在 预计完成时间 上方
- L列人员通过「人员部门对应关系表.csv」映射到部门名
- 若无变化则不更新

用法:
  python3 sheet_to_md.py --csv-file data.csv --md-dir /path/to/md --dept-csv dept.csv [--dry-run]
"""

import csv
import io
import json
import os
import re
import subprocess
import sys
from pathlib import Path

# ── 配置 ──────────────────────────────────────────────────────────────
DEFAULT_MD_DIR = "/Users/wujin/0000WorkFiles/myobsidian/Obsidian-Notes/需求分析/"
DEFAULT_DEPT_CSV = "/Volumes/Macintosh HD_Data/WorkBuddy/腾讯文档/人员部门对应关系表.csv"
MCP_PORTER_PATH = "/Users/wujin/.npm-global/bin/mcporter"

# ── MCP 调用工具 ──────────────────────────────────────────────────────
def call_mcp(tool_name: str, args: dict) -> dict:
    """通过 mcporter 调用 tencent-docs 的 MCP 工具"""
    cmd = [
        MCP_PORTER_PATH,
        "call",
        "tencent-docs",
        tool_name,
        "--args",
        json.dumps(args)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise Exception(f"MCP 调用失败 (工具: {tool_name}):\nError: {res.stderr}\nOutput: {res.stdout}")
    
    try:
        return json.loads(res.stdout)
    except json.JSONDecodeError:
        raise Exception(f"MCP 返回的数据无法解析为 JSON:\n{res.stdout}")


# ── CSV 列索引 (0-based) ──────────────────────────────────────────────
IDX_DATE      = 0   # A: 提出日期
IDX_PRIORITY  = 1   # B: 优先级
IDX_LINK      = 2   # C: 需求链接
IDX_NAME      = 3   # D: 需求名称
IDX_DESC      = 4   # E: 需求描述
IDX_SYSTEMS   = 5   # F: 涉及系统
IDX_RELATED   = 6   # G: 关联系统
IDX_SCHEDULE  = 7   # H: 计划排期
IDX_STORY     = 8   # I: story拆分
IDX_STATUS    = 9   # J: 评审状态
IDX_REMARK    = 10  # K: 备注
IDX_ATTENDEES = 11  # L: 参会人员


# ── 部门映射 ────────────────────────────────────────────────────────────

def load_dept_map(csv_path: str) -> dict[str, str]:
    """加载「人员部门对应关系表.csv」，返回 {人名: 部门} 映射。
    csv 格式：第一行表头(人员,部门)，后续每行一行记录。
    """
    dept_map = {}
    if not csv_path or not Path(csv_path).is_file():
        return dept_map

    text = Path(csv_path).read_text(encoding='utf-8')
    reader = csv.reader(io.StringIO(text))
    try:
        next(reader)  # 跳过表头
    except StopIteration:
        return dept_map

    for line in reader:
        if len(line) < 2:
            continue
        name = line[0].strip()
        dept = line[1].strip()
        if name and dept:
            dept_map[name] = dept
    return dept_map


# ── MD 匹配 ────────────────────────────────────────────────────────────

def find_md_file(req_name: str, md_dir: str) -> Path | None:
    """根据需求名称匹配本地 MD 文件。

    匹配策略（按优先级）：
    1. 需求名称完整出现在文件名中
    2. 需求名称中的【XX】标签全部出现在文件名中
    3. 剔除日期前缀后的核心名称出现在文件名中
    """
    base = Path(md_dir)
    if not base.is_dir():
        return None

    name = req_name.strip()
    if not name:
        return None

    md_files = list(base.glob("*.md"))

    # 策略1: 完整名称匹配
    for f in md_files:
        if name in f.name:
            return f

    # 策略2: 【】标签匹配
    tags = re.findall(r'【(.+?)】', name)
    if tags:
        for f in md_files:
            if all(tag in f.name for tag in tags):
                return f

    # 策略3: 去日期前缀匹配
    core = re.sub(r'^\d{8}-需求-', '', name)
    for f in md_files:
        if core in f.name:
            return f

    return None


# ── MD 解析 ────────────────────────────────────────────────────────────

SECTION_TECH    = "#### **三、技术实现**"
SECTION_REVIEW  = "#### **评审纪要**"
SECTION_LINKS   = "**相关链接**"

# 旧版 v1 "在线文档同步信息" 引用块（需清理）
V1_SYNC_BLOCK   = re.compile(
    r'> \*\*在线文档同步信息\*\*[：:][^\n]*\n(?:> .*\n)*'
)

# 新版自然融入行（用于检测已有值）
RE_SYSTEMS_LINE = re.compile(r'^涉及系统[：:]\s*(.+)$', re.MULTILINE)
RE_RELATED_LINE = re.compile(r'^关联系统[：:]\s*(.+)$', re.MULTILINE)
RE_TIME_LINE    = re.compile(r'^预计完成时间[：:]\s*(.+)$', re.MULTILINE)
RE_REMARK_LINE  = re.compile(r'^> \*\*备注\*\*[：:]\s*(.+)$', re.MULTILINE)

# 评审纪要编号条目: N. **标题**：内容
RE_NUM_ITEM = re.compile(r'^(\d+)\.\s+\*\*(.+?)\*\*[：:](.+?)$', re.MULTILINE)

# 备注→标题动词提取
_REMARK_VERBS = ['核对', '确认', '验证', '检查', '梳理', '补充', '优化', '完善', '调整', '新增', '解决', '处理', '评估']

# 评审纪要第一句：日期 + 沟通评审
# 新格式: 日期经与**部门A**人员A和**部门B**人员B沟通评审通过
RE_REVIEW_FIRST = re.compile(
    r'^(\d{4}年\d{2}月\d{2}日)经与(.+?)沟通评审通过$',
    re.MULTILINE
)


class MdSections:
    """MD 文件分段结构"""
    def __init__(self, content: str):
        self.raw = content
        self.preamble = ""       # 技术实现之前的内容
        self.tech = ""           # 三、技术实现 整块
        self.review = ""         # 评审纪要 整块
        self.tail = ""           # 评审纪要之后的内容
        self.has_tech = False
        self.has_review = False
        self._parse()

    def _parse(self):
        t = self.raw
        tech_i = t.find(SECTION_TECH)
        review_i = t.find(SECTION_REVIEW)
        links_i = t.find(SECTION_LINKS)

        if tech_i >= 0:
            self.has_tech = True
            self.preamble = t[:tech_i].rstrip()
            if review_i > tech_i:
                self.tech = t[tech_i:review_i].rstrip()
            else:
                self.tech = t[tech_i:].rstrip()
                return
        else:
            self.preamble = t.rstrip()
            return

        if review_i >= 0:
            self.has_review = True
            if links_i > review_i:
                self.review = t[review_i:links_i].rstrip()
                self.tail = t[links_i:]
            else:
                self.review = t[review_i:].rstrip()
        else:
            self.tail = t[review_i:]

    def rebuild(self) -> str:
        """把分段重新拼回完整内容"""
        parts = [self.preamble]
        if self.has_tech:
            parts.append(self.tech)
        if self.has_review:
            parts.append(self.review)
        parts.append(self.tail)
        return '\n\n'.join(p for p in parts if p)


# ── 文本工具 ────────────────────────────────────────────────────────────

def _clean_multiline(s: str) -> str:
    """清理换行 → 用 、 连接"""
    return '、'.join(line.strip() for line in s.split('\n') if line.strip())


# ── 技术实现 更新 ──────────────────────────────────────────────────────

def _strip_v1_sync_block(tech: str) -> str:
    """移除旧版 v1 的「在线文档同步信息」引用块"""
    return V1_SYNC_BLOCK.sub('', tech).rstrip()


def _get_current_related_from_tech(tech: str) -> str:
    """从技术实现章节提取当前已写入的「关联系统」值"""
    m = RE_RELATED_LINE.search(tech)
    return m.group(1).strip() if m else ''


def update_tech_section(tech: str, remark: str) -> tuple[str, bool]:
    """在 技术实现 中自然融入 备注(K)。

    返回 (更新后文本, 是否有变更)
    """
    changed = False

    # 1. 清理旧版 v1 引用块（含旧版涉及系统行）
    old_tech = tech
    tech = _strip_v1_sync_block(tech)
    
    # 清理残留在技术实现中的涉及系统行和关联系统行（已迁移到评审纪要）
    if RE_SYSTEMS_LINE.search(tech):
        tech = RE_SYSTEMS_LINE.sub('', tech)
    if RE_RELATED_LINE.search(tech):
        tech = RE_RELATED_LINE.sub('', tech)

    # 移除已有的临时备注标记（如果有）以避免重复
    tech = re.sub(r'<!-- REMARK_START -->.*?<!-- REMARK_END -->\n*', '', tech, flags=re.DOTALL)

    if tech != old_tech:
        changed = True

    # 2. 如果存在备注，且尚未被并入，则作为待合并标记插入
    if remark and remark.strip():
        remark_clean = remark.strip()
        if remark_clean not in tech:
            header_pattern = re.compile(r'^(#### \*\*三、技术实现\*\*)\s*\n', re.MULTILINE)
            m = header_pattern.search(tech)
            if m:
                insert_pos = m.end()
                insert_text = f"<!-- REMARK_START -->\n备注：{remark_clean}\n<!-- REMARK_END -->\n\n"
                tech = tech[:insert_pos] + insert_text + tech[insert_pos:].lstrip('\n')
                changed = True

    # 避免连续3个以上空行
    tech = re.sub(r'\n{3,}', '\n\n', tech)

    return tech, changed


# ── 评审纪要 更新 ──────────────────────────────────────────────────────

def _extract_names(raw: str) -> list[str]:
    """从 L列文本中提取独立人名。支持换行、顿号、逗号分隔。
    例如 "杜伟毅\n吴进\n厉凌杰\n许曼莉" → ["杜伟毅","吴进","厉凌杰","许曼莉"]
    """
    if not raw or not raw.strip():
        return []
    # 按换行、顿号、中文逗号、英文逗号拆分
    parts = re.split(r'[\n、，,]+', raw.strip())
    return [p.strip() for p in parts if p.strip()]


def _parse_attendees(attendees_raw: str, dept_map: dict[str, str]) -> list[tuple[str, list[str]]]:
    """解析参会人员列，返回按部门分组的结构。

    流程：
    1. 若 L列含部门前缀（XX部-人员）→ 直接解析分组
    2. 若无部门前缀 → 通过 dept_map 查每个人的部门，按部门分组

    返回 [(部门, [人员列表]), ...] 保持原始顺序
    """
    if not attendees_raw or not attendees_raw.strip():
        return []

    raw = attendees_raw.strip()

    # 检查是否含部门前缀（XX部-或XX室-或XX组-）
    has_dept = re.search(r'[\u4e00-\u9fff]{2,6}[部室组处科中心]-', raw)

    if has_dept:
        # 格式: "融资融券部-张三、营运部-李四"
        parts = re.split(r'[、，,\n]+', raw)
        groups: dict[str, list[str]] = {}
        group_order: list[str] = []
        for p in parts:
            p = p.strip()
            if not p:
                continue
            m = re.match(r'^(.+?)-(.+)$', p)
            if m:
                dept = m.group(1).strip()
                person = m.group(2).strip()
                if dept not in groups:
                    groups[dept] = []
                    group_order.append(dept)
                if person not in groups[dept]:
                    groups[dept].append(person)
        return [(d, groups[d]) for d in group_order]

    # 无部门前缀 → 通过 dept_map 查询
    names = _extract_names(raw)
    if not names:
        return []

    if not dept_map:
        return [("[部门名称A]", names)]

    # 按部门分组: {部门: [人员列表]}
    dept_groups: dict[str, list[str]] = {}
    dept_order: list[str] = []
    unknown: list[str] = []

    for name in names:
        dept = dept_map.get(name, '')
        if dept:
            if dept not in dept_groups:
                dept_groups[dept] = []
                dept_order.append(dept)
            dept_groups[dept].append(name)
        else:
            unknown.append(name)

    result: list[tuple[str, list[str]]] = [(d, dept_groups[d]) for d in dept_order]
    if unknown:
        result.append(("[部门名称A]", unknown))

    return result


def _generate_remark_title(remark: str) -> str:
    """从备注文本智能生成编号项加粗标题"""
    remark = remark.strip().rstrip('。，；,;.')
    if not remark:
        return '补充说明'

    # 尝试匹配动词 → 取动词后的关键名词
    for verb in _REMARK_VERBS:
        if verb in remark:
            idx = remark.index(verb)
            after = remark[idx + len(verb):].strip()
            if after:
                # 提取关键名词短语：移除连接词，取前 2-6 字
                key = re.sub(r'[跟与和及以及的之了是]', '', after)[:6]
                if key:
                    return f'{key}{verb}'
            return f'相关{verb}'

    # 无动词匹配：取前 8 字
    return remark[:8]


def _merge_remark_into_items(review: str, remark: str) -> tuple[str, bool]:
    """将备注内容融入评审纪要的编号列表中。

    策略：
    1. 清理旧版 `> **备注**` 行
    2. 检查备注内容是否已存在于某条目中 → 跳过
    3. 尝试按关键词重叠合并到语义最接近的条目
    4. 无法合并则新增一条编号条目（N+1）

    返回 (更新后文本, 是否有变更)
    """
    if not remark or not remark.strip():
        return review, False

    remark_text = remark.strip().rstrip('。，；,;.')
    changed = False

    # ── 1. 清理旧版 `> **备注**` 行 ──
    if RE_REMARK_LINE.search(review):
        review = RE_REMARK_LINE.sub('', review)
        review = re.sub(r'\n{3,}', '\n\n', review)
        changed = True

    # ── 2. 解析现有编号条目 ──
    items = list(RE_NUM_ITEM.finditer(review))

    # ── 3. 检查是否已存在 ──
    for m in items:
        existing = m.group(3).strip().rstrip('。，；')
        if remark_text in existing or existing in remark_text:
            return review, changed  # 已存在，无需更新

    # ── 4. 关键词重叠 → 尝试合并到最匹配条目 ──
    # 构建 remark 的纯文本词集
    remark_words = set(remark_text.replace('跟', ' ').replace('和', ' ').replace('与', ' ').replace('及', ' ').split())

    best_match = None
    best_score = 0
    for m in items:
        item_content = m.group(3).strip().rstrip('。，；')
        item_words = set(item_content.replace('跟', ' ').replace('和', ' ').replace('与', ' ').replace('及', ' ').split())
        overlap = len(remark_words & item_words)
        if overlap > best_score:
            best_score = overlap
            best_match = m

    if best_match and best_score >= 2:
        # 合并：在已有条目末尾追加备注（分号分隔）
        old_item = best_match.group(0)
        existing_content = best_match.group(3).strip().rstrip('。')
        new_content = f'{existing_content}；{remark_text}。'
        new_item = old_item.replace(best_match.group(3), new_content)
        review = review.replace(old_item, new_item)
        return review, True

    # ── 5. 新增编号条目 ──
    max_num = max([int(m.group(1)) for m in items], default=0)
    new_num = max_num + 1
    title = _generate_remark_title(remark_text)
    new_item = f'{new_num}. **{title}**：{remark_text}。'

    # 插入到最后一条编号条目之后
    if items:
        last_item = items[-1]
        end_pos = last_item.end()
        # 匹配行尾，在其后插入
        review = review[:end_pos] + '\n' + new_item + review[end_pos:]
    else:
        # 无编号条目：插入到第一句话之后
        first_line_end = review.find('\n')
        if first_line_end > 0:
            review = review[:first_line_end + 1] + '\n' + new_item + review[first_line_end + 1:]
        else:
            review += '\n\n' + new_item

    # 清理连续空行
    review = re.sub(r'\n{3,}', '\n\n', review)

    return review, True


def update_review_section(review: str, schedule: str, remark: str,
                          attendees: str, systems: str, related: str, date_str: str,
                          dept_map: dict[str, str]) -> tuple[str, bool]:
    """更新 评审纪要 部分。

    - L列(参会人员) → 通过 dept_map 查部门，填充第一句话
    - K列(备注)     → 融入编号列表（在 评审纪要 中以临时标记插入，待 Agent LLM 智能融合）
    - F列(涉及系统) → 涉及系统行
    - G列(关联系统) → 关联系统行（放在涉及系统下方）
    - H列(计划排期) → 预计完成时间
    """
    changed = False

    # ── 1. 第一句话：参会人员 ──
    if attendees and attendees.strip():
        dept_groups = _parse_attendees(attendees, dept_map)

        if dept_groups:
            # 格式: **部A**人A、**部B**人B和**部C**人C
            group_strs = []
            for dept, people in dept_groups:
                people_str = '、'.join(people)
                group_strs.append(f"**{dept}**{people_str}")

            if len(group_strs) == 1:
                attendee_part = group_strs[0]
            elif len(group_strs) == 2:
                attendee_part = '和'.join(group_strs)
            else:
                attendee_part = '、'.join(group_strs[:-1]) + '和' + group_strs[-1]
        else:
            attendee_part = r"**[部门名称A]**：[人员X]、[人员Y]"

        first_line = f"{date_str}经与{attendee_part}沟通评审通过"

        # 检测当前第一句
        old_first = RE_REVIEW_FIRST.search(review)
        if old_first:
            if old_first.group(0) != first_line:
                review = review.replace(old_first.group(0), first_line)
                changed = True
        else:
            # 没有匹配到标准格式的第一句，尝试匹配任意"日期...沟通评审通过"行
            first_line_match = re.match(
                r'^(\d{4}年\d{2}月\d{2}日).+?沟通评审通过',
                review
            )
            if first_line_match:
                old_line = first_line_match.group(0)
                if old_line != first_line:
                    review = review.replace(old_line, first_line, 1)
                    changed = True

    # ── 2. 备注 → 融入编号列表的临时标记 ──
    # 移除旧的临时备注标记（如果有）以避免重复，也清理旧版 > **备注** 行
    review = re.sub(r'<!-- REMARK_START -->.*?<!-- REMARK_END -->\n*', '', review, flags=re.DOTALL)
    if RE_REMARK_LINE.search(review):
        review = RE_REMARK_LINE.sub('', review)
        changed = True

    if remark and remark.strip():
        remark_clean = remark.strip()
        if remark_clean not in review:
            first_line_match = RE_REVIEW_FIRST.search(review)
            if not first_line_match:
                first_line_match = re.match(r'^(\d{4}年\d{2}月\d{2}日).+?沟通评审通过', review)
            
            insert_pos = first_line_match.end() if first_line_match else 0
            if insert_pos > 0:
                insert_text = f"\n\n<!-- REMARK_START -->\n备注：{remark_clean}\n<!-- REMARK_END -->"
                review = review[:insert_pos] + insert_text + review[insert_pos:]
                changed = True
            else:
                insert_text = f"<!-- REMARK_START -->\n备注：{remark_clean}\n<!-- REMARK_END -->\n\n"
                review = insert_text + review
                changed = True

    # ── 3. 涉及系统 与 关联系统 (涉及系统下方) ──
    systems_clean = _clean_multiline(systems) if systems else ''
    related_clean = _clean_multiline(related) if related else ''

    # 清除旧的涉及系统和关联系统行
    old_review = review
    review = RE_SYSTEMS_LINE.sub('', review)
    review = RE_RELATED_LINE.sub('', review)
    if review != old_review:
        changed = True

    # 组合为新块
    lines_to_insert = []
    if systems_clean:
        lines_to_insert.append(f'涉及系统：{systems_clean}')
    if related_clean:
        lines_to_insert.append(f'关联系统：{related_clean}')

    if lines_to_insert:
        sys_related_block = "\n".join(lines_to_insert) + "\n"
        # 寻找“预计完成时间”插入点
        time_pos = review.find('预计完成时间')
        if time_pos > 0:
            review = review[:time_pos] + sys_related_block + review[time_pos:]
        else:
            review = review.rstrip() + f'\n\n{sys_related_block}'
        changed = True

    # ── 4. 预计完成时间 ──
    if schedule and schedule.strip():
        time_str = f"预计完成时间：计划 {schedule.strip()}"
        old_time = RE_TIME_LINE.search(review)
        if old_time:
            if old_time.group(0) != time_str:
                review = review.replace(old_time.group(0), time_str)
                changed = True
        else:
            review = review.rstrip() + f'\n\n{time_str}\n'
            changed = True

    # 整理空行
    review = re.sub(r'\n{3,}', '\n\n', review)

    return review, changed


# ── J列 评审状态 过滤 ──────────────────────────────────────────────

APPROVED_STATUSES = {'通过', '评审通过'}

def is_approved(status: str) -> bool:
    """判断评审状态是否为「通过」"""
    s = status.strip()
    return s in APPROVED_STATUSES


# ── 主流程 ─────────────────────────────────────────────────────────────

def process_row(row: dict, md_dir: str, dry_run: bool,
                dept_map: dict[str, str]) -> dict:
    """处理单行数据"""
    name = row.get('name', '').strip()
    if not name:
        return {"status": "skip", "name": "", "message": "需求名称为空"}

    # ── J列过滤：仅「通过」才处理 ──
    status = row.get('status', '')
    if not is_approved(status):
        return {
            "name": name,
            "status": "skipped_not_approved",
            "message": f"评审状态为「{status}」非「通过」，跳过"
        }

    md_file = find_md_file(name, md_dir)
    if not md_file:
        return {
            "name": name,
            "status": "no_match",
            "message": f"未找到匹配的 MD 文件（搜索: {md_dir}）"
        }

    # 读取 MD
    try:
        content = md_file.read_text(encoding='utf-8')
    except Exception as e:
        return {"name": name, "status": "error", "message": str(e)}

    sections = MdSections(content)
    changes = []

    # 从日期列提取日期字符串
    date_raw = row.get('date', '')
    date_str = _extract_date(date_raw)

    # 更新 技术实现 (K: 备注)
    if sections.has_tech:
        new_tech, tech_changed = update_tech_section(
            sections.tech,
            row.get('remark', '')
        )
        if tech_changed:
            sections.tech = new_tech
            changes.append('技术实现')

    # 更新 评审纪要 (F:涉及系统, G:关联系统, H:排期, K:备注, L:参会人员)
    if sections.has_review:
        new_review, review_changed = update_review_section(
            sections.review,
            row.get('schedule', ''),
            row.get('remark', ''),
            row.get('attendees', ''),
            row.get('systems', ''),
            row.get('related', ''),
            date_str,
            dept_map
        )
        if review_changed:
            sections.review = new_review
            changes.append('评审纪要')

    if not changes:
        return {
            "name": name,
            "file": str(md_file),
            "status": "unchanged",
            "message": "内容已是最新，无需更新"
        }

    new_content = sections.rebuild()

    return {
        "name": name,
        "file": str(md_file),
        "status": "updated",
        "changes": changes,
        "new_content": new_content,
        "dry_run": dry_run
    }


def _extract_date(date_raw: str) -> str:
    """从日期列提取格式化日期字符串，如 '2026/6/1' → '2026年06月01日'"""
    if not date_raw:
        return "2026年06月01日"  # 默认
    for fmt in [r'(\d{4})/(\d{1,2})/(\d{1,2})', r'(\d{4})-(\d{1,2})-(\d{1,2})']:
        m = re.search(fmt, date_raw)
        if m:
            return f"{m.group(1)}年{int(m.group(2)):02d}月{int(m.group(3)):02d}日"
    return date_raw


def parse_csv(csv_text: str) -> list[dict]:
    """解析 mcporter sheet.get_cell_data 返回的 CSV"""
    reader = csv.reader(io.StringIO(csv_text))
    rows = []
    try:
        next(reader)  # 跳过表头
    except StopIteration:
        return rows

    for line in reader:
        # 补齐列数
        while len(line) < 13:
            line.append('')

        name = line[IDX_NAME].strip() if len(line) > IDX_NAME else ''
        # 过滤：需求名称必须非空且看起来像真实需求（含中文且长度≥3）
        if not name or len(name) < 3 or not any('\u4e00' <= c <= '\u9fff' for c in name):
            continue

        rows.append({
            'date':      line[IDX_DATE].strip()      if len(line) > IDX_DATE      else '',
            'name':      name,
            'systems':   line[IDX_SYSTEMS].strip()   if len(line) > IDX_SYSTEMS   else '',
            'related':   line[IDX_RELATED].strip()   if len(line) > IDX_RELATED   else '',
            'schedule':  line[IDX_SCHEDULE].strip()  if len(line) > IDX_SCHEDULE  else '',
            'remark':    line[IDX_REMARK].strip()    if len(line) > IDX_REMARK    else '',
            'status':    line[IDX_STATUS].strip()    if len(line) > IDX_STATUS    else '',
            'attendees': line[IDX_ATTENDEES].strip() if len(line) > IDX_ATTENDEES else '',
        })
    return rows


def main():
    import argparse
    ap = argparse.ArgumentParser(description='腾讯文档 Sheet → Obsidian MD 反写')
    ap.add_argument('biz', nargs='?', choices=['rzrq', 'gpzy', 'qt'], help='业务类型: rzrq (融资融券), gpzy (股票质押) 或 qt (其他)')
    ap.add_argument('--csv-file', help='CSV 数据文件路径 (若不指定则自动通过 MCP 获取)')
    ap.add_argument('--md-dir',    default=DEFAULT_MD_DIR, help='本地 MD 文件目录')
    ap.add_argument('--dept-csv',  default=DEFAULT_DEPT_CSV, help='人员部门对应关系表 CSV 路径')
    ap.add_argument('--dry-run',   action='store_true', help='预览模式，不修改文件')
    ap.add_argument('--json',      action='store_true', help='JSON 格式输出')
    ap.add_argument('--output-dir', help='输出目录：将更新后的内容写入此目录下的临时文件供 agent 使用')
    ap.add_argument('--apply',     action='store_true', help='直接写入 MD 文件（当脚本有写入权限时）')
    args = ap.parse_args()

    # 加载部门映射
    dept_map = load_dept_map(args.dept_csv) if args.dept_csv else {}
    if args.dept_csv:
        print(f"📋 已加载 {len(dept_map)} 条人员部门映射")
    else:
        print("⚠️  未提供 --dept-csv，L列人员将按无部门前缀处理")

    if not args.csv_file:
        biz_file_map = {
            "rzrq": "DVGtPSXpzWU1zYXNi",
            "gpzy": "DVEtyb05taEFDc0xL",
            "qt": "DVE9Gb0daTmtzUE9H"
        }
        biz = args.biz if args.biz else "rzrq"
        file_id = biz_file_map[biz]
        print(f"📡 自动通过 MCP 获取 {biz} 的在线表格结构 ({file_id})...")
        try:
            sheet_info = call_mcp("sheet.get_sheet_info", {"file_id": file_id})
        except Exception as e:
            print(f"❌ 获取在线表格结构失败: {e}", file=sys.stderr)
            sys.exit(1)

        sheets = sheet_info.get("sheets", [])
        if not sheets:
            print("❌ 未在目标表格中找到子表", file=sys.stderr)
            sys.exit(1)

        # 默认取第一个子表
        target_sheet = sheets[0]
        sheet_id = target_sheet["sheet_id"]
        row_count = target_sheet["row_count"]
        sheet_name = target_sheet["sheet_name"]
        print(f"📡 正在读取子表 '{sheet_name}' (ID: {sheet_id}, 行数: {row_count}) 的数据...")
        
        try:
            cell_data = call_mcp("sheet.get_cell_data", {
                "file_id": file_id,
                "sheet_id": sheet_id,
                "start_row": 0,
                "end_row": row_count,
                "start_col": 0,
                "end_col": 12,
                "return_csv": True
            })
        except Exception as e:
            print(f"❌ 读取表格数据失败: {e}", file=sys.stderr)
            sys.exit(1)

        csv_text = cell_data.get("csv_data", "")
    else:
        csv_text = Path(args.csv_file).read_text(encoding='utf-8')
    rows = parse_csv(csv_text)

    if not rows:
        print("⚠️ CSV 中无有效数据行", file=sys.stderr)
        sys.exit(1)

    results = []
    for row in rows:
        r = process_row(row, args.md_dir, args.dry_run, dept_map)
        results.append(r)

    # 输出到独立文件（供 agent 用 Write 工具写入）
    if args.output_dir:
        out_dir = Path(args.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        for r in results:
            if r['status'] == 'updated' and r.get('new_content'):
                out_file = out_dir / Path(r['file']).name
                out_file.write_text(r['new_content'], encoding='utf-8')
                r['output_file'] = str(out_file)

    # 直接写入（有权限时）
    if args.apply:
        for r in results:
            if r['status'] == 'updated' and r.get('new_content'):
                try:
                    Path(r['file']).write_text(r['new_content'], encoding='utf-8')
                    r['written'] = True
                except PermissionError:
                    r['written'] = False
                    r['write_error'] = '权限不足'
                except Exception as e:
                    r['written'] = False
                    r['write_error'] = str(e)

    # ── 输出 ──
    if args.json:
        clean = [{k: v for k, v in r.items() if k != 'new_content'} for r in results]
        print(json.dumps(clean, ensure_ascii=False, indent=2))
    else:
        updated = 0
        skipped = 0
        for r in results:
            name = r.get('name', '?')
            if r['status'] == 'updated':
                action = "预览" if r.get('dry_run') else "更新"
                written = ""
                if r.get('output_file'):
                    written = f" → {r['output_file']}"
                elif r.get('written'):
                    written = " (已写入)"
                elif r.get('write_error'):
                    written = f" (写入失败: {r['write_error']})"
                print(f"✅ [{name}]: {action}了 {', '.join(r['changes'])}{written}")
                updated += 1
            elif r['status'] == 'unchanged':
                print(f"⏭️  [{name}]: 内容已是最新")
            elif r['status'] == 'skipped_not_approved':
                print(f"⏭️  [{name}]: {r['message']}")
                skipped += 1
            elif r['status'] == 'no_match':
                print(f"⚠️  [{name}]: {r['message']}")
            elif r['status'] == 'error':
                print(f"❌ [{name}]: {r['message']}")
        print(f"\n📊 共 {len(results)} 条记录: {updated} 条更新, "
              f"{len(results) - updated - skipped} 条跳过, {skipped} 条非通过状态过滤")

    # 返回码
    has_error = any(r['status'] == 'error' for r in results)
    sys.exit(1 if has_error else 0)


if __name__ == '__main__':
    main()
